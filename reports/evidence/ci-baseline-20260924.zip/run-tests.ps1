param([string]$Name, [string[]]$TestArgs)
$ErrorActionPreference = 'Continue'
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$env:PYTHONDONTWRITEBYTECODE='1'
$env:JARVIS_HEADLESS='1'
$env:JARVIS_MOCK_AUDIO='1'
$env:JARVIS_SANDBOX_ALLOW_COMPAT_FALLBACK='1'
$env:GOOGLE_API_KEY='test_dummy_ci_key'
$env:JARVIS_RUN_LIVE_NETWORK_TESTS='0'
$env:JARVIS_RUN_LIVE_INFRA_TESTS='0'
$env:JARVIS_RUN_LIVE_IMAP_TESTS='0'
$env:JARVIS_RUN_BROWSER_E2E= if($Name -like 'browser*'){'1'}else{'0'}
$env:PLAYWRIGHT_BROWSERS_PATH=Join-Path $PWD '.baseline-tools/browsers'
$env:JARVIS_BROWSER_EVIDENCE_DIR=Join-Path $PWD 'reports/evidence/ci-baseline-20260924/browser-artifacts'
$env:PYTEST_DEBUG_TEMPROOT=Join-Path $PWD '.baseline-tools/pytest-temp'
New-Item -ItemType Directory -Force $env:PYTEST_DEBUG_TEMPROOT | Out-Null
$out=Join-Path $PWD 'reports/evidence/ci-baseline-20260924'
$start=[DateTime]::UtcNow
$sw=[Diagnostics.Stopwatch]::StartNew()
& ../runtime/venv/Scripts/python.exe -m pytest @TestArgs -v --tb=long --timeout=120 "--junit-xml=$out/$Name.xml" *> "$out/$Name.txt"
$ec=$LASTEXITCODE
$sw.Stop()
[ordered]@{name=$Name;started_utc=$start.ToString('o');head=(git rev-parse HEAD);command="../runtime/venv/Scripts/python.exe -m pytest $($TestArgs -join ' ') -v --tb=long --timeout=120 --junit-xml=$out/$Name.xml";exit_code=$ec;wall_seconds=$sw.Elapsed.TotalSeconds} | ConvertTo-Json | Set-Content "$out/$Name.meta.json"
Get-Content "$out/$Name.txt" -Tail 12
Write-Output "EXIT=$ec WALL_SECONDS=$($sw.Elapsed.TotalSeconds)"
exit $ec
