import json, os, subprocess, time
from pathlib import Path
import yaml
root=Path('reports/evidence/ci-baseline-20260924')
w=yaml.safe_load(Path('.github/workflows/ci.yml').read_text(encoding='utf-8'))
env=dict(os.environ, JARVIS_HEADLESS='1', JARVIS_MOCK_AUDIO='1', PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
env['PATH']=str(Path('../runtime/venv/Scripts').resolve())+os.pathsep+env['PATH']
results=[]
for job in ('syntax','imports'):
    for index,step in enumerate(w['jobs'][job]['steps']):
        if not step.get('name','').startswith(('Check -','Validate module')): continue
        script=Path('.baseline-tools')/f'{job}-{index}.ps1'
        script.write_text(step['run'],encoding='utf-8')
        t=time.perf_counter()
        p=subprocess.run(['pwsh','-NoProfile','-File',str(script)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (root/f'{job}-{index}.txt').write_bytes(p.stdout)
        results.append(dict(job=job,step=step['name'],command=f'pwsh -NoProfile -File {script}',exit_code=p.returncode,seconds=time.perf_counter()-t))
        print(results[-1])
(root/'static-ci-steps.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
