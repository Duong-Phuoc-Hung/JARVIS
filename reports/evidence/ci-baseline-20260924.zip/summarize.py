import json, re, xml.etree.ElementTree as ET
from pathlib import Path
root = Path('reports/evidence/ci-baseline-20260924')
items=[]
for meta in sorted(root.glob('*.meta.json')):
    row=json.loads(meta.read_text(encoding='utf-8-sig'))
    name=row.setdefault('name', meta.name.removesuffix('.meta.json'))
    log=root/f'{name}.txt'
    if log.exists():
        lines=log.read_text(encoding='utf-8-sig', errors='replace').splitlines()
        row['console_summary']=[line.strip('= ') for line in lines if re.search(r'\d+ (passed|failed|skipped|error).* in [\d.]+s',line)][-1:]
    xml=root/f'{name}.xml'
    if xml.exists():
        tree=ET.parse(xml)
        row['junit_suites']=[s.attrib for s in tree.getroot().iter('testsuite')]
        row['failures']=[]
        row['skips']=[]
        for tc in tree.getroot().iter('testcase'):
            node=tc.get('classname','').replace('.','/')+'::'+tc.get('name','')
            for tag in ('failure','error'):
                error=tc.find(tag)
                if error is not None:
                    row['failures'].append({'node':node,'kind':tag,'message':error.get('message','')})
            skip=tc.find('skipped')
            if skip is not None:
                row['skips'].append({'node':node,'reason':skip.get('message','')})
    items.append(row)
(root/'summary.json').write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for row in items:
    print(row['name'],row.get('console_summary'),row['exit_code'])
    for failure in row.get('failures',[]): print(failure['node'],failure['message'][:240])
